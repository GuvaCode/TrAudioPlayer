#!/bin/bash

# -------------------------------------------
rm -rvf build-linux{64,32}
rm -rvf build-windows{64,32}

# -------------------------------------------- 
# Linux64 build 
mkdir build-linux64
cd build-linux64
cmake ..-DBUILD_SHARED_LIBS=ON -DBUILD_PROGRAMS=OFF -DBUILD_EXAMPLES=OFF -DBUILD_TESTING=OFF
make -j$(nproc)
cp libsndfile.so.1.0.37 ../../../library/lin64/libsndfile.so
cd ..

# Linux32 build 
mkdir build-linux32
cd build-linux32
cmake .. -DBUILD_SHARED_LIBS=ON -DBUILD_PROGRAMS=OFF -DBUILD_EXAMPLES=OFF -DBUILD_TESTING=OFF -DCMAKE_CXX_FLAGS=-m32

make -j$(nproc)
cp libsndfile.so.1.0.37 ../../../library/lin32/libsndfile.so
cd ..
# ------------------------------------------
# Windows64
mkdir build-windows64
cd build-windows64
cmake .. -DBUILD_SHARED_LIBS=ON -DBUILD_PROGRAMS=OFF -DBUILD_EXAMPLES=OFF -DBUILD_TESTING=OFF -DCMAKE_TOOLCHAIN_FILE=../toolchainX64-mingw.cmake 
make -j$(nproc)
cp libsndfile.dll ../../../library/win64/
cd ..

# Windows32
mkdir build-windows32
cd build-windows32
cmake .. -DBUILD_SHARED_LIBS=ON -DBUILD_PROGRAMS=OFF -DBUILD_EXAMPLES=OFF -DBUILD_TESTING=OFF -DCMAKE_TOOLCHAIN_FILE=../toolchainX32-mingw.cmake 
make -j$(nproc)
cp libsndfile.dll ../../../library/win32/
cd ..
# ---------------------------------------

rm -rvf build-linux{64,32}
rm -rvf build-windows{64,32}

