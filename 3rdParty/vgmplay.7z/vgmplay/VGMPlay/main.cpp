#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <fstream>
#include <cstring>
#include <cmath>


#ifdef __cplusplus
extern "C" {
#endif
#include "chips/mamedef.h"	// for (U)INTxx types
#include "VGMPlay.h"
#include "VGMPlay_Intf.h"
#ifdef __cplusplus
}
#endif

    
