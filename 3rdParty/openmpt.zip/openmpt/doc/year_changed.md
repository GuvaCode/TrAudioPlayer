
Things to update when the year has changed
==========================================

 *  `LICENSE` (1 occurrence)
 *  `src/mpt/LICENSE.BSD-3-Clause.txt` (1 occurrence)
 *  `common/version.cpp` (2 occurrences plus 1 for each current contributor)
 *  `mptrack/res/MPTRACK.RC2` (1 occurence)
 *  `pluginBridge/PluginBridge.rc` (1 occurence)
 *  `installer/install-multi-arch.iss` (1 occurence)
 *  `installer/install-multi-arch-retro.iss` (1 occurence)
 *  `libopenmpt/libopenmpt_version.rc`) (1 occurrence)
 *  `openmpt123/openmpt123.cpp` (3 occurrences)
 *  `libopenmpt/xmp-openmpt/xmp-openmpt.cpp` (1 occurrence)
 *  `libopenmpt/in_openmpt/in_openmpt.cpp` (1 occurrence)
 *  `contrib/libmodplug-0.8.8.5/LICENSE` (1 occurrence)
 *  `contrib/libmodplug-0.8.9.0/LICENSE` (1 occurrence)
 *  [https://wiki.openmpt.org/Manual:_Acknowledgments](https://wiki.openmpt.org/Manual:_Acknowledgments)
 *  [https://lib.openmpt.org/libopenmpt/license/](https://lib.openmpt.org/libopenmpt/license/)

