# Сборка Linux 32-bit версии с явным указанием компилятора

make clean

# Использование 32-битных компиляторов
export CC="gcc -m32"
export CXX="g++ -m32"

./configure --enable-shared \
            --disable-static \
            --disable-examples \
            --disable-tests \
            --build=i686-pc-linux-gnu

make SHARED_LIB=1 STATIC_LIB=1 EXAMPLES=0 TEST=0 LDFLAG=-m32

strip bin/libopenmpt.so.6
cp bin/libopenmpt.so.6 ../../library/lin32/libopenmpt.so

echo "32-bit сборка завершена!"
