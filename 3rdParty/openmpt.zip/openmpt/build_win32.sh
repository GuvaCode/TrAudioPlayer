#!/bin/bash

# Полная очистка
make CONFIG=mingw-w64 clean

# Создаем директорию для билд-файлов
mkdir -p build

# Генерируем BuildSettings.hpp
echo "Generating BuildSettings.hpp..."
cat > build/openmpt/all/BuildSettings.hpp << 'EOF'
#pragma once

#define OPENMPT_VERSION_MAJOR 0
#define OPENMPT_VERSION_MINOR 7
#define OPENMPT_VERSION_PATCH 0
#define OPENMPT_VERSION_PREREL ""

#define OPENMPT_VERSION_CURRENT 0x00070000

#define OPENMPT_API_VERSION_MAJOR 0
#define OPENMPT_API_VERSION_MINOR 7
#define OPENMPT_API_VERSION_PATCH 0

#define OPENMPT_VERSION_IS_PACKAGED 0
#define OPENMPT_VERSION_IS_MAKE 1
#define OPENMPT_VERSION_IS_CLEAN 1
#define OPENMPT_VERSION_HAS_URL 0
#define OPENMPT_VERSION_HAS_DATE 0
#define OPENMPT_VERSION_HAS_REVISION 0

#define OPENMPT_PROJECT_URL ""
EOF

# Установка переменных окружения для x86 (32-bit)
export CXX=i686-w64-mingw32-g++-posix
export CC=i686-w64-mingw32-gcc-posix

# Компиляция для 32-bit
make CONFIG=mingw-w64 WINDOWS_ARCH=x86 SHARED_LIB=1 STATIC_LIB=1 EXAMPLES=0 TEST=0
cp bin/libopenmpt.dll ../../../library/win32/

make clean
